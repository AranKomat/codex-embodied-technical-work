import torch
from control import Driver, quat_apply

def run(env):
    s=env.scene; d=Driver(env)
    print('Initial physical status:',s.seated().tolist(),flush=True)
    p=s.card.data.root_pos_w.clone()
    band=torch.tensor([0.,.0154,.1005],device=env.device).expand(env.num_envs,3)
    g=p+quat_apply(s.card.data.root_quat_w,band)
    g[:,2]+=.1034
    high=g.clone(); high[:,2]+=.15
    d.move(high,steps=120,label='above')
    d.move(g,steps=100,label='grasp approach')
    d.move(g,grip=0.,steps=80,label='closed')
    if not s.grasp_held.all(): return
    lift=s.card.data.root_pos_w.clone(); lift[:,2]+=.22
    d.card_move(lift,steps=140,label='lift')
    if not s.grasp_held.all(): return
    seat=s.case.data.root_pos_w+quat_apply(s.case.data.root_quat_w,torch.tensor(s.cfg.seat_pos,device=env.device).expand(env.num_envs,3))
    target=seat.clone(); target[:,0]-=.045; target[:,2]+=.18
    d.card_move(target,steps=170,label='transfer')
    target[:,2]=seat[:,2]+.012
    d.card_move(target,steps=160,label='lower forward')
    target[:,0]=seat[:,0]
    d.card_move(target,steps=130,label='rear slide')
    target[:,2]=seat[:,2]-.001
    d.card_move(target,steps=160,label='press')
    hp,hq=d.pose(); d.move(hp.clone(),hq.clone(),grip=.04,steps=50,label='release')
    hp,hq=d.pose(); hp=hp.clone(); hp[:,2]+=.15
    d.move(hp,hq.clone(),steps=80,label='retreat')
    print('FINAL seated',s.seated().tolist(),'depth',s.engaged().tolist(),flush=True)

def check(env): return bool(env.scene.seated().all())
