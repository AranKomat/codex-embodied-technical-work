# plan: [stage 1/1] card seated and released
# origin=fresh
from assessment import history
print(history(),flush=True)
import sys
sys.argv += ['--/plugins/carb.tasking.plugin/threadCount=4']
from isaaclab.app import AppLauncher
app=AppLauncher(headless=True,enable_cameras=True)
import torch; torch.set_num_threads(1)
import robobench; robobench.discover()
from robobench.core.registries import ENVS
import sys,os,traceback
sys.path.insert(0,'/workspace/solution')
env=ENVS.get('assembly.server_repair.franka.osc')().build(num_envs=1)
env.reset()
from checkpoint_tree import CheckpointTree
from scene_view import Viewer
from assessment import assess
tree=CheckpointTree(env); tree.plan(['card seated and released'])
v=Viewer(env,eye=(1.,-1.,.85),target=(.45,-.08,.08))
v.snapshot('before')
try:
    print('ENV interfaces', [x for x in dir(env) if 'diag' in x or 'tool' in x or 'health' in x],flush=True)
    from pxr import UsdGeom
    for prim in env.stage.Traverse():
        if '/Case/' in str(prim.GetPath()) and any(x in prim.GetName().lower() for x in ['rear','cutout','panel','channel']):
            print('GEOM',prim.GetPath(),[(a.GetName(),a.Get()) for a in prim.GetAttributes() if 'xformOp:' in a.GetName() or a.GetName()=='size'],flush=True)
    import control
    original=control.Driver.move
    def watched(self,*a,**kw):
        out=original(self,*a,**kw)
        if kw.get('label'): v.snapshot(kw['label'])
        return out
    control.Driver.move=watched
    result=tree.run_stage(1)
    print('RESULT',result,flush=True)
except Exception: traceback.print_exc()
v.snapshot('after')
print('METRIC',env.scene.seated().tolist(),env.scene.engaged().tolist(),flush=True)
assess(scene='Visual assessment pending image transport.',log=str(env.scene.card.data.root_state_w.tolist()),failure_modes='Baseline results require examination.',outcome='ok' if env.scene.seated().all() else 'failed',tree=tree,program=__file__,constants_plan='Not yet a viable maneuver; diagnosing baseline.')
print('DONE',flush=True)
os._exit(0)
