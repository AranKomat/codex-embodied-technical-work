# plan: grasp strategy comparison; origin=fresh
import sys
sys.argv += ['--/plugins/carb.tasking.plugin/threadCount=4']
from assessment import history
print(history(),flush=True)
from isaaclab.app import AppLauncher
app=AppLauncher(headless=True)
import torch
from isaaclab.utils.math import quat_mul,quat_conjugate,axis_angle_from_quat
from sweep import sweep

def grasp(env,ids,heading=0):
    a=env.robot.articulation; h=a.body_names.index('panda_hand')
    n=len(ids); q=torch.tensor([0.,0.,1.,0.] if heading==0 else [0.,1.,0.,0.],device=env.device).repeat(n,1)
    p=env.scene.card.data.root_pos_w[ids].clone(); p+=torch.tensor([-.04,.0154,.2039],device=env.device)
    bias=torch.zeros((n,6),device=env.device)
    for phase,steps in enumerate([70,100,65]):
        goal=p.clone()
        if phase==0: goal[:,2]+=.10
        for i in range(steps):
            cp=a.data.body_pos_w[ids,h]; cq=a.data.body_quat_w[ids,h]
            dq=quat_mul(q,quat_conjugate(cq)); dq=torch.where(dq[:,:1]<0,-dq,dq)
            err=torch.cat([goal-cp,axis_angle_from_quat(dq)],-1)
            bias+=err.clamp(-.02,.02)*.025
            delta=err*.9+bias
            act=torch.zeros((n,8),device=env.device)
            act[:,:3]=delta[:,:3].clamp(-.035,.035)/.02
            act[:,3:6]=delta[:,3:].clamp(-.18,.18)/.097
            act[:,6:]=.04 if phase<2 else 0.
            yield act
        print('PHASE',heading,phase,'held',env.scene.grasp_held[ids].tolist(),'hand',a.data.body_pos_w[ids,h].tolist(),'q',a.data.body_quat_w[ids,h].tolist(),'joints',a.data.joint_pos[ids].tolist(),flush=True)

def obj(env): return 1-env.scene.grasp_held[:,0].float()
print(sweep('assembly.server_repair.franka.osc',candidates=[(grasp,{'heading':0}),(grasp,{'heading':1})],objective=obj,num_envs=4),flush=True)
import os;os._exit(0)
