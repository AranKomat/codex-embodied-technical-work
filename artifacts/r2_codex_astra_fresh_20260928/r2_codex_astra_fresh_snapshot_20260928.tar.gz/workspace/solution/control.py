import torch
from isaaclab.utils.math import quat_mul, quat_conjugate, axis_angle_from_quat, quat_apply

class Driver:
    def __init__(self, env):
        self.env=env; self.art=env.robot.articulation
        self.h=self.art.body_names.index('panda_hand')
        self.bias=torch.zeros((env.num_envs,6),device=env.device)
        self.q=torch.tensor([0.,0.,1.,0.],device=env.device).repeat(env.num_envs,1)
    def pose(self):
        return self.art.data.body_pos_w[:,self.h],self.art.data.body_quat_w[:,self.h]
    def move(self,p,q=None,grip=.04,steps=100,label=''):
        p=torch.as_tensor(p,device=self.env.device).reshape(-1,3).expand(self.env.num_envs,3)
        q=self.q if q is None else q
        for i in range(steps):
            cp,cq=self.pose()
            dq=quat_mul(q,quat_conjugate(cq)); dq=torch.where(dq[:,:1]<0,-dq,dq)
            err=torch.cat([p-cp,axis_angle_from_quat(dq)],-1)
            self.bias += err.clamp(-.02,.02) * .025
            self.bias[:,:3].clamp_(-.10,.10); self.bias[:,3:].clamp_(-.6,.6)
            delta=err*.9+self.bias
            delta[:,:3].clamp_(-.035,.035); delta[:,3:].clamp_(-.18,.18)
            a=torch.zeros((self.env.num_envs,8),device=self.env.device)
            a[:,:3]=delta[:,:3]/.02; a[:,3:6]=delta[:,3:]/.097; a[:,6:]=grip
            self.env.step(a)
        if label: print(label,'hand',self.pose()[0].tolist(),'hq',self.pose()[1].tolist(),'fingers',self.art.data.joint_pos[:,-2:].tolist(),'card',self.env.scene.card.data.root_pos_w.tolist(),'quat',self.env.scene.card.data.root_quat_w.tolist(),'held',self.env.scene.grasp_held.tolist(),flush=True)
    def card_move(self,p,steps=100,label=''):
        # Closed-loop correction of the held card position and orientation.
        target=torch.as_tensor(p,device=self.env.device).reshape(-1,3).expand(self.env.num_envs,3)
        for i in range(steps):
            hp,hq=self.pose(); c=self.env.scene.card
            cq=c.data.root_quat_w; cp=c.data.root_pos_w
            caseq=self.env.scene.case.data.root_quat_w
            rot=quat_mul(caseq,quat_conjugate(cq))
            tq=quat_mul(rot,hq)
            tp=target+quat_apply(rot,hp-cp)
            self.move(tp,tq,grip=.017,steps=1)
        if label: print(label,'card',self.env.scene.card.data.root_pos_w.tolist(),'quat',self.env.scene.card.data.root_quat_w.tolist(),'held',self.env.scene.grasp_held.tolist(),'depth',self.env.scene.engaged().tolist(),flush=True)
