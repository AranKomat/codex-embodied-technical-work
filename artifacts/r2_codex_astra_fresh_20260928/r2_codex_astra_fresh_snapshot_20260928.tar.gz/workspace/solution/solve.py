def solve(env):
    from stages.stage_1 import run
    run(env)
